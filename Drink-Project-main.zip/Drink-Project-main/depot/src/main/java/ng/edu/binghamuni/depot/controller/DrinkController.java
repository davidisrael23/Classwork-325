package ng.edu.binghamuni.depot.controller;

import org.springframework.stereotype.Controller;

@Controller
public class DrinkController {

}
