package ng.edu.binghamuni.depot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepotApplication {

    public static void main(String[] args) {
        SpringApplication.run(DepotApplication.class, args);
    }

}
